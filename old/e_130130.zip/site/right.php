<div style="_width:200px;height:100%;_background-color:blue;">

<?php
require_once(dirname(__FILE__)."/../php/module.php");
modulo("brisa", "Libro:<br/> &quot;Por qu&eacute; r&iacute;e la brisa&quot;");

modulo("fotos", "Galer&iacute;a de fotos");
?>



</div>
