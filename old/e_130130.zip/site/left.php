<div style="_width:200px;_height:100%;">

<?php
require_once(dirname(__FILE__)."/../php/module.php");
modulo("menu", "Men&uacute;");

modulo("pensamientos", "Pensamientos");
?>






</div>
