<?php
print_r("oo");


?>