<script type="text/javascript">

function goto3(a, divblog)
{
	goto(a, divblog);
}

</script>	

<div style="max-width:900px;height:100%;">


<div id="blog2" >

<?php
global $params, $divblog;
$params = array("t2");
$divblog="blog2";
require(dirname(__FILE__)."/blog.php");
?>
</div>


</div>
