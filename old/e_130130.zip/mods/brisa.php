
<a href="/porquerielabrisa_libro" id="idad">
<img src="./images/portada03.jpg" style="width:160px;height:135px;" id="ad3" name="ad_porquerielabrisa_libro"/>
</a>

<script type="text/javascript">

		function aclick(e){
			e.stopPropagation();
			return false;
		}
			$("#ad3").mouseover(pmenuover);
			$("#ad3").mouseleave(pmenuexit);
			$("#ad3").click(pmenuclick);
		$("#idad").click(rclick);
</script>			
