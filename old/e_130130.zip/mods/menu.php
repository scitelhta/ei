


<ul class="mmenu">
<li><a class="rlink" href="./"><div class="rmenu" id="ru9" name="pp_">Inicio</div></a></li>
<li><a class="rlink" href="./about"><div class="rmenu" id="ru1" name="pp_about">Fundaci&oacute;n</div></a></li>
<li><a class="rlink" href="./events"><div class="rmenu" id="ru2" name="pp_events">Pr&oacute;ximos Eventos</div></a></li>
<li><ul><a class="rlink" href="/acts"><div class="rmenu" id="ru9" name="pp_acts">Actividades</div></a>
		<li><a class="rlink" href="./ayahuasca"><div class="rmenu" id="ra9" name="pp_ayahuasca">Ayahuasca</div></a></li>
		<li><a class="rlink" href="./meditacion"><div class="rmenu" id="rb9" name="pp_meditacion">Meditaci&oacute;n</div></a></li>
		<li><a class="rlink" href="./abrazos"><div class="rmenu" id="rc9" name="pp_abrazos">Abrazos Gratis</div></a></li>
		<li><a class="rlink" href="./caminata"><div class="rmenu" id="rd9" name="pp_caminata">Caminata tem&aacute;tica</div></a></li>
	</ul>
</li>
<li><a class="rlink" href="./porquerielabrisa_libro"><div class="rmenu" id="ru3" name="pp_porquerielabrisa_libro">Por qu&eacute; r&iacute;e la brisa</div></a></li>
<li><a class="rlink" href="./media"><div class="rmenu" id="ru7" name="pp_media">M&uacute;sica y Videos</div></a></li>
<li><a class="rlink" href="./blog"><div class="rmenu" id="ru8" name="pp_blog">Pensamientos</div></a></li>

</ul>
<script type="text/javascript">

		function rclick(e){
			e.stopPropagation();
			return false;
		}

			$(".rmenu").mouseover(pmenuover);
			$(".rmenu").mouseleave(pmenuexit);
			$(".rmenu").click(pmenuclick);
		$(".rlink").click(rclick);
</script>			
