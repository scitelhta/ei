<?php
$myarts=array("brisasong" => array("Canci&oacute;n", "&iquest;Por qu&eacute; r&iacute;e la brisa&#63;") 
				);
?>