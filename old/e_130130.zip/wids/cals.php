<?php
$myarts=array("eproximos" => array("Pr&oacute;ximos Eventos", "&iquest;A d&oacute;nde quieres ir&#63;"), 
				"emensual" => array("Calendario Mensual", "&iquest;Cu&aacute;ndo quieres ir&#63;")
				//"eregistrar" => array("Registrar Evento", "Inv&iacute;tanos")
				);
?>