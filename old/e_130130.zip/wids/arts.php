<?php
$myarts=array("ayahuasca" => array("Ayahuasca", "La Liana del Alma"), "meditacion" => array("Meditaci&oacute;n",""));
?>